﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerDataUI : MonoBehaviour {

    public Text playerHealthText;

    public Text playerCurrencyText;

    public PlayerData playerData;

    public Text deathText; 

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (playerData)
        {
            playerHealthText.text = playerData.playerHealth.ToString();
            playerCurrencyText.text = playerData.playerCurrency.ToString();
        }
        
	}
}
