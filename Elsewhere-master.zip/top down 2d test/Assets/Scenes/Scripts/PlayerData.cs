﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 

public class PlayerData : MonoBehaviour {

    public int playerHealth;

    public int playerHealthMax;

    public int playerCurrency;

    public int playerCurrencyMax;

    public bool playerAlive;

    public bool dashObtained;

    public bool shieldObtained;

    public bool projectileObtained;

    public bool healObtained;

    public bool boss1Killed;

    public bool boss2Killed;

    public bool boss3Killed;

    public bool boss4Killed;

    public bool boss5Killed;

    public GameObject playercube;

    public PlayerDataUI playerDataUI;

    public PlayerController2D playerController2D; 

	void Start () {
        playerHealth = 100;
        playerHealthMax = 100;
        playerCurrency = 0;
        playerCurrencyMax = 500;
        playerAlive = true;
        dashObtained = false;
        shieldObtained = false;
        projectileObtained = false;
        healObtained = false; 
	}
    public void Update()
    {
        if (playerHealth <= 0)
        {
            playerAlive = false; 
        }
    }

}
